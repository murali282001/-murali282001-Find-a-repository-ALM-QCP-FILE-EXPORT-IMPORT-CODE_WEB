/**
 * app.js — QCP Export & Import Tool  (frontend logic)
 * =====================================================
 * - Reads connection fields shared across both tabs
 * - SSE-based real-time log delivery
 * - localStorage-based credential vault (secrets never leave the browser)
 * - Export: triggers file download when server signals ready
 * - Import: shows project details in a success modal
 */

"use strict";

// ─── localStorage vault keys ────────────────────────────────────────────────
const VAULT_KEY   = "qcp_vault";      // { clientId: encryptedSecret }
const CONN_KEY    = "qcp_conn";       // { base_url, domain }

// ─── Restore saved connection on load ───────────────────────────────────────
window.addEventListener("DOMContentLoaded", () => {
  const conn = JSON.parse(localStorage.getItem(CONN_KEY) || "{}");
  if (conn.base_url) document.getElementById("base_url").value = conn.base_url;
  if (conn.domain)   document.getElementById("domain").value   = conn.domain;

  // Wire forms
  document.getElementById("exportForm").addEventListener("submit", onExport);
  document.getElementById("importForm").addEventListener("submit", onImport);

  // Auto-lookup when Client ID loses focus
  document.getElementById("client_id").addEventListener("blur", autoFillSecret);
});

// ─── Helpers ────────────────────────────────────────────────────────────────

function getConn() {
  return {
    base_url:      document.getElementById("base_url").value.trim(),
    domain:        document.getElementById("domain").value.trim(),
    client_id:     document.getElementById("client_id").value.trim(),
    client_secret: document.getElementById("client_secret").value.trim(),
  };
}

function validateConn() {
  const c = getConn();
  const errs = [];
  if (!c.base_url)      errs.push("Base URL is required");
  if (c.base_url && !c.base_url.startsWith("http")) errs.push("Base URL must start with http:// or https://");
  if (!c.domain)        errs.push("Domain is required");
  if (!c.client_id)     errs.push("Client ID is required");
  if (!c.client_secret) errs.push("Client Secret is required");
  return errs;
}

function maybeSaveConn() {
  if (!document.getElementById("rememberConn").checked) return;
  const c = getConn();
  localStorage.setItem(CONN_KEY, JSON.stringify({
    base_url: c.base_url,
    domain:   c.domain,
  }));
}

function makeSessionId() {
  return crypto.randomUUID();
}

// ─── Credential vault (localStorage) ────────────────────────────────────────

function getVault() {
  return JSON.parse(localStorage.getItem(VAULT_KEY) || "{}");
}

function saveKey() {
  const cid = document.getElementById("client_id").value.trim();
  const sec = document.getElementById("client_secret").value.trim();
  if (!cid || !sec) {
    alert("Enter both Client ID and Client Secret before saving.");
    return;
  }
  const vault = getVault();
  vault[cid] = sec;           // stored in browser — never sent to server
  localStorage.setItem(VAULT_KEY, JSON.stringify(vault));
  showBadge("Key saved ✓", "text-success");
  addLog("INFO", `Key saved for Client ID: ${cid}`);
}

function autoFillSecret() {
  const cid   = document.getElementById("client_id").value.trim();
  const vault = getVault();
  if (cid && vault[cid]) {
    document.getElementById("client_secret").value = vault[cid];
    showBadge("Key found ✓", "text-success");
  } else if (cid) {
    showBadge("No stored key", "text-muted");
  }
}

function showBadge(text, cls) {
  const badge = document.getElementById("vaultBadge");
  badge.classList.remove("d-none", "text-success", "text-muted", "text-danger");
  badge.classList.add(cls);
  badge.querySelector("i").className = "bi bi-key-fill me-1";
  badge.lastChild.textContent        = text;
}

function openManageKeys() {
  const vault = getVault();
  const tbody = document.getElementById("keysTableBody");
  tbody.innerHTML = "";
  const ids = Object.keys(vault);
  if (ids.length === 0) {
    tbody.innerHTML = `<tr><td colspan="2" class="text-muted text-center">No keys stored</td></tr>`;
  } else {
    ids.forEach(cid => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="align-middle font-monospace small">${escHtml(cid)}</td>
        <td class="text-center">
          <button class="btn btn-danger btn-sm py-0"
                  onclick="deleteKey('${escHtml(cid)}')">
            <i class="bi bi-trash"></i> Delete
          </button>
        </td>`;
      tbody.appendChild(tr);
    });
  }
  new bootstrap.Modal(document.getElementById("manageKeysModal")).show();
}

function deleteKey(cid) {
  const vault = getVault();
  delete vault[cid];
  localStorage.setItem(VAULT_KEY, JSON.stringify(vault));
  openManageKeys();   // refresh the modal
  addLog("INFO", `Key deleted for Client ID: ${cid}`);
}

// ─── SSE log stream ──────────────────────────────────────────────────────────

function openSSE(sessionId, onDone, onError) {
  const src = new EventSource(`/api/events?session_id=${sessionId}`);
  src.onmessage = (e) => {
    const item = JSON.parse(e.data);
    if (item.type === "ping")  return;
    if (item.type === "log")   { addLog(item.level, item.msg, item.time); return; }
    if (item.type === "done")  { src.close(); onDone(item);  return; }
    if (item.type === "error") { src.close(); onError(item.msg); return; }
  };
  src.onerror = () => {
    src.close();
    onError("Connection to server lost. Check that the server is running.");
  };
  return src;
}

// ─── Export ──────────────────────────────────────────────────────────────────

async function onExport(e) {
  e.preventDefault();
  const connErrs = validateConn();
  if (connErrs.length) { alert(connErrs.join("\n")); return; }

  const project = document.getElementById("exp_project").value.trim();
  if (!project) { alert("Project name is required."); return; }

  const conn      = getConn();
  const sessionId = makeSessionId();

  setExportRunning(true);
  maybeSaveConn();
  addLog("INFO", `Starting export for project: ${project}`);

  // Open SSE first, then POST
  openSSE(
    sessionId,
    (done) => {
      setExportRunning(false);
      // Trigger browser file download
      const link = document.createElement("a");
      link.href  = `/api/download/${done.token}`;
      link.click();
      addLog("INFO", `File ready: ${done.filename}  (${done.size_kb} KB)`);
    },
    (errMsg) => {
      setExportRunning(false);
      addLog("ERROR", errMsg);
      alert(`Export failed:\n\n${errMsg}`);
    },
  );

  // POST to start the export worker
  const fd = new FormData();
  fd.append("base_url",      conn.base_url);
  fd.append("domain",        conn.domain);
  fd.append("project",       project);
  fd.append("client_id",     conn.client_id);
  fd.append("client_secret", conn.client_secret);
  fd.append("session_id",    sessionId);

  const resp = await fetch("/api/export", { method: "POST", body: fd });
  if (!resp.ok) {
    const txt = await resp.text();
    setExportRunning(false);
    addLog("ERROR", `Failed to start export: ${txt}`);
    alert(`Failed to start export:\n${txt}`);
  }
}

function setExportRunning(state) {
  const btn  = document.getElementById("expBtn");
  const wrap = document.getElementById("expProgressWrap");
  const sts  = document.getElementById("expStatus");
  btn.disabled = state;
  btn.innerHTML = state
    ? `<span class="spinner-border spinner-border-sm me-1"></span>Exporting…`
    : `<i class="bi bi-download me-1"></i>Export QCP`;
  wrap.classList.toggle("d-none", !state);
  if (state) sts.textContent = "Working…";
}

function clearExport() {
  document.getElementById("exp_project").value = "";
  document.getElementById("expProgressWrap").classList.add("d-none");
  document.getElementById("expStatus").textContent = "";
}

// ─── Import ──────────────────────────────────────────────────────────────────

async function onImport(e) {
  e.preventDefault();
  const connErrs = validateConn();
  if (connErrs.length) { alert(connErrs.join("\n")); return; }

  const file        = document.getElementById("imp_file").files[0];
  const projectName = document.getElementById("imp_project_name").value.trim();
  const dbServer    = document.getElementById("imp_db_server").value.trim();
  const dbType      = document.getElementById("imp_db_type").value;
  const tablespace  = document.getElementById("imp_tablespace").value.trim();
  const tempTs      = document.getElementById("imp_temp_tablespace").value.trim();
  const skipLab     = document.getElementById("imp_skip_lab").checked;

  const errs = [];
  if (!file)        errs.push("QCP File is required");
  if (!projectName) errs.push("Project Name is required");
  if (!dbServer)    errs.push("DB Server is required");
  if (errs.length)  { alert(errs.join("\n")); return; }

  const conn      = getConn();
  const sessionId = makeSessionId();

  if (!confirm(
    `Import QCP file into domain '${conn.domain}' as new project '${projectName}'?\n\n` +
    `File: ${file.name}\nDB:   ${dbType === "2" ? "MS SQL Server" : "Oracle"} / ${dbServer}\n\n` +
    `This will CREATE a new project on the server.`
  )) return;

  setImportRunning(true);
  maybeSaveConn();
  addLog("INFO", `Starting import: ${file.name}  →  project '${projectName}'`);

  openSSE(
    sessionId,
    (done) => {
      setImportRunning(false);
      showImportSuccess(done.project);
    },
    (errMsg) => {
      setImportRunning(false);
      addLog("ERROR", errMsg);
      alert(`Import failed:\n\n${errMsg}`);
    },
  );

  const fd = new FormData();
  fd.append("base_url",        conn.base_url);
  fd.append("domain",          conn.domain);
  fd.append("client_id",       conn.client_id);
  fd.append("client_secret",   conn.client_secret);
  fd.append("session_id",      sessionId);
  fd.append("project_name",    projectName);
  fd.append("db_server",       dbServer);
  fd.append("db_type",         dbType);
  fd.append("tablespace",      tablespace);
  fd.append("temp_tablespace", tempTs);
  fd.append("skip_lab",        skipLab ? "true" : "false");
  fd.append("qcp_file",        file);

  const resp = await fetch("/api/import", { method: "POST", body: fd });
  if (!resp.ok) {
    const txt = await resp.text();
    setImportRunning(false);
    addLog("ERROR", `Failed to start import: ${txt}`);
    alert(`Failed to start import:\n${txt}`);
  }
}

function showImportSuccess(project) {
  const body = document.getElementById("importSuccessBody");
  body.innerHTML = `
    <table class="table table-sm table-borderless mb-0">
      <tr><th style="width:120px">Project Name</th><td>${escHtml(project.name || "?")}</td></tr>
      <tr><th>Project ID</th><td>${escHtml(String(project.id || "?"))}</td></tr>
      <tr><th>Domain</th><td>${escHtml(project["domain-name"] || "?")}</td></tr>
      <tr><th>DB Name</th><td>${escHtml(project["db-name"] || "?")}</td></tr>
      <tr><th>Version</th><td>${escHtml(project.version || "?")}</td></tr>
    </table>`;
  new bootstrap.Modal(document.getElementById("importSuccessModal")).show();
}

function setImportRunning(state) {
  const btn  = document.getElementById("impBtn");
  const wrap = document.getElementById("impProgressWrap");
  btn.disabled = state;
  btn.innerHTML = state
    ? `<span class="spinner-border spinner-border-sm me-1"></span>Importing…`
    : `<i class="bi bi-upload me-1"></i>Import QCP`;
  wrap.classList.toggle("d-none", !state);
}

function clearImport() {
  document.getElementById("importForm").reset();
  document.getElementById("imp_tablespace").value      = "QC_ADMIN";
  document.getElementById("imp_temp_tablespace").value = "TEMP";
  document.getElementById("impProgressWrap").classList.add("d-none");
}

// ─── Log box ─────────────────────────────────────────────────────────────────

const LOG_COLORS = {
  INFO:    "log-info",
  WARNING: "log-warn",
  WARN:    "log-warn",
  ERROR:   "log-error",
  DEBUG:   "log-debug",
};

function addLog(level, msg, time) {
  const box  = document.getElementById("logBox");
  const cls  = LOG_COLORS[level] || "log-info";
  const ts   = time || new Date().toLocaleTimeString("en-GB");
  const line = document.createElement("div");
  line.className = `log-line ${cls}`;
  line.textContent = `[${ts}] [${level.padEnd(5)}] ${msg}`;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
}

function clearLog() {
  document.getElementById("logBox").innerHTML = "";
}

// ─── Utility ─────────────────────────────────────────────────────────────────

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
